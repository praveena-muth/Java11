package com.hlag.logisticsystem;


public class Derived extends Base {


	public Derived() {
		super(10, 20);
	}



	@Override
	public void test() {
		System.out.println("Derived");
	}


}
