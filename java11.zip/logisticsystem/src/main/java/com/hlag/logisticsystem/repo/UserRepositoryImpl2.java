package com.hlag.logisticsystem.repo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import com.hlag.user.entity.User;

public class UserRepositoryImpl2 implements UserRepository {

	public static void main(String[] args) {
		Runnable runnable = () -> {
			UserRepositoryImpl2 userRepositoryImpl = getInstance();
			System.out.println(userRepositoryImpl.hashCode());
		};
		Thread thread = new Thread(runnable);
		thread.start();
		Thread thread2 = new Thread(runnable);
		thread2.start();
		Thread thread3 = new Thread(runnable);
		thread3.start();

	}


	private Set<User> users = new HashSet<>();
	private static UserRepositoryImpl2 userRepositoryImpl;

	private UserRepositoryImpl2() {
	}

	public static UserRepositoryImpl2 getInstance() {
		synchronized (UserRepositoryImpl2.class) {
			if (userRepositoryImpl == null) {
				userRepositoryImpl = new UserRepositoryImpl2();
			}
		}

		 return userRepositoryImpl;
	}

	@Override
	public User addUser(User user) {
		boolean result = users.add(user);
		if (result) {
			return user;
		}
		return null;
	}

	@Override
	public Optional<User> getUserById(String id) {
		UUID uuid = UUID.fromString(id);
		return users.stream().filter(e -> e.getId().equals(uuid)).findFirst();
	}

	@Override
	public Optional<List<User>> getUsers() {
		if (users.isEmpty()) {
			return Optional.empty();
		} else {
			return Optional.of(new ArrayList<>(users));
		}
	}

	@Override
	public void deleteUser(String id) {
		boolean isRemoved = users.removeIf(user -> user.getId().equals(id));
		if (isRemoved) {
			System.out.println("User with ID " + id + " has been deleted.");
		} else {
			System.out.println("User with ID " + id + " not found.");
		}
	}

	@Override
	public User updateUser(String id, User user) {

		return null;
	}

}

