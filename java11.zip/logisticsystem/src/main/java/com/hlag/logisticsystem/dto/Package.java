package com.hlag.logisticsystem.dto;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

public class Package {

	private final String trackingId;
	private double weight;
	private String destination;
	private String status;
	private List<String> milestones;



	// public Package(String trackingId, String destination, double weight) {
	// this.trackingId = trackingId;//
	// this.destination = destination;
	// this.status = "In Transit"; // Initial status
	// this.milestones = new ArrayList<>();
	// setWeight(weight);
	// }
	//
	// public String getTrackingId() {
	// return trackingId;
	// }

	public double getWeight() {
		return weight;
	}

	public String getDestination() {
		return destination;
	}

	public String getStatus() {
		return status;
	}

	public List<String> getMilestones() {
		return Collections.unmodifiableList(milestones);
	}

	public void setWeight(double weight) {
		if (weight <= 0) {
			throw new IllegalArgumentException("Weight must be positive");
		}
		this.weight = weight;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setMilestones(List<String> milestones) {
		this.milestones = milestones;
	}

	public void markAsDelivered(String status) {
		// in transist
		if (this.status.equals(status)) {
			throw new IllegalArgumentException("Package is already delivered");
		}
		this.status = "Delivered";
		this.milestones.add("Delivered on " + LocalDate.now());
		// delivered @ so : so date so :so time.
	}

	private Package() {
		this.trackingId = "";
	}

	private static Package pack;

	public static Package getInstance() {
		if (pack == null) {
			pack = new Package();
		}
		return pack;
	}

}
