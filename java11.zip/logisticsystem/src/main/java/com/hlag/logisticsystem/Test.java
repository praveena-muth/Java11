package com.hlag.logisticsystem;

public class Test {

	public static void main(String[] args) {
		Flyable flyable = new Ironman();
		test(flyable);
	}

	private static void test(Flyable flyable) {

		System.out.println("Test");
	}

}
