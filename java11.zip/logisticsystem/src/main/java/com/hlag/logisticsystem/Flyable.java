package com.hlag.logisticsystem;


public interface Flyable {

	public void fly();
}
