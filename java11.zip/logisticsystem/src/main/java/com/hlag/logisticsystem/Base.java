package com.hlag.logisticsystem;


public class Base {

	int value1;
	int value2;

	public Base(int value1, int value2) {
	}

	public void test() {
		System.out.println("Base");
	}
}


