package com.hlag.logisticsystem;


public class Ironman implements Flyable {

	@Override
	public void fly() {
		System.out.println("Ironman flying");
	}

	public void test() {
		System.out.println("Ironman");
	}
}
