package com.hlag.aircargosystem.cargomanagementsystem;

public class CargoManagementTest {

	public static void main(String[] args) {

		CargoManagementSystem cargoManagement = new CargoManagementSystem();
        
		Cargo electronics = new Cargo(1, "Electronics", 20.5);
		Cargo furniture = new Cargo(2, "Furniture", 35.2);
		Cargo clothing = new Cargo(3, "Clothing", 15.8);

		cargoManagement.addCargo(electronics);
		cargoManagement.addCargo(furniture);
		cargoManagement.addCargo(clothing);

		cargoManagement.removeCargo(2);

		cargoManagement.displayCargo();

}
}