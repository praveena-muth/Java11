package com.hlag.aircargosystem.cargomanagementsystem;

public class Cargo {

	private int id;
	private String name;
	private double weight;

	public Cargo(int id, String name, double weight) {
		this.id = id;
		this.name = name;
		this.weight = weight;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	@Override
	public String toString() {
		return "Cargo [id=" + id + ", name=" + name + ", weight=" + weight + "]";
	}


}
