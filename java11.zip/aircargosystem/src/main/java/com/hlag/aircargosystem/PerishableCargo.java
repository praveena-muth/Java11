package com.hlag.aircargosystem;


public class PerishableCargo extends Cargo {

	public PerishableCargo() {
		super("2", "PerishableCargo", 123);
	}

	@Override
	public void test() {
		System.out.println("PerishableCargo");
	}
}
