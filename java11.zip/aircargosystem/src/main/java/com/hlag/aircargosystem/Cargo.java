package com.hlag.aircargosystem;


public class Cargo {

	String cargoId;
	String description;
	int weight;

	public Cargo(String cargoId, String description, int weight) {
	}

	public void test() {
		System.out.println("Cargo");
	}
}
