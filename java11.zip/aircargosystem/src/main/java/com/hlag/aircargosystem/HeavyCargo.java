package com.hlag.aircargosystem;


public class HeavyCargo extends Cargo {


	public HeavyCargo() {
		super("1", "Heavy", 123);
	}

	@Override
	public void test() {
		System.out.println("HeavyCargo");
	}
}
