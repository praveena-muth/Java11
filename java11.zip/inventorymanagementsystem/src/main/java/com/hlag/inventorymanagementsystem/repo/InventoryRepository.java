package com.hlag.inventorymanagementsystem.repo;

import java.util.List;
import java.util.Optional;

import com.hlag.inventorymanagementsystem.entity.Product;

public interface InventoryRepository {

	public Product addProduct(Product product);

	public Optional<Product> getProductById(String id);

	public Optional<List<Product>> getProducts();

	public void deleteProduct(String id);

	public Product updateProduct(String id, Product product);

}
