package com.hlag.inventorymanagementsystem.app;

import java.util.List;
import java.util.Optional;
import java.util.Scanner;

import com.hlag.inventorymanagementsystem.entity.Product;
import com.hlag.inventorymanagementsystem.exception.InvalidNameException;
import com.hlag.inventorymanagementsystem.service.InventoryService;
import com.hlag.inventorymanagementsystem.service.InventoryServiceImpl;

public class App {

	public static void main(String[] args) throws InvalidNameException {

		InventoryService inventoryService = InventoryServiceImpl.getInstance();
		Scanner scanner = new Scanner(System.in);

		int choice;
		do {
			// Display Menu Options
			printMenu();
			choice = scanner.nextInt();
			scanner.nextLine();

			switch (choice) {
				case 1:
					addProduct(inventoryService, scanner);
					break;
				case 2:
					viewProducts(inventoryService);
					break;
				case 3:
					updateProduct(inventoryService, scanner);
					break;
				case 4:
					deleteProduct(inventoryService, scanner);
					break;
				case 0:
					System.out.println("Exiting the application...");
					break;
				default:
					System.out.println("Invalid choice! Please try again.");
			}

		} while (choice != 0);
	}

	// Menu options for the user
	public static void printMenu() {
		System.out.println("\nInventory Management System");
		System.out.println("1. Add Product");
		System.out.println("2. View All Products");
		System.out.println("3. Update Product");
		System.out.println("4. Delete Product");
		System.out.println("0. Exit");
		System.out.print("Enter your choice: ");
	}

	// Add a new product
	public static void addProduct(InventoryService inventoryService, Scanner scanner) {
		System.out.print("Enter product name: ");
		String name = scanner.nextLine();
		System.out.print("Enter product description: ");
		String description = scanner.nextLine();
		System.out.print("Enter product price: ");
		double price = scanner.nextDouble();
		System.out.print("Enter product quantity: ");
		int quantity = scanner.nextInt();

		try {
			Product product = new Product(name, description, price, quantity);
			Product addedProduct = inventoryService.addProduct(product);
			System.out.println("Product added successfully! ID: " + addedProduct.getProductId());
		} catch (InvalidNameException e) {
			System.out.println("Error: " + e.getMessage());
		}
	}


	// View all products
	public static void viewProducts(InventoryService inventoryService) {
		Optional<List<Product>> products = inventoryService.getProducts();
		if (products.isPresent() && !products.get().isEmpty()) {
			System.out.println("\nList of Products:");
			for (Product product : products.get()) {
				System.out.println(product);
			}
		} else {
			System.out.println("No products available.");
		}
	}

	// Update product details
	public static void updateProduct(InventoryService inventoryService, Scanner scanner) throws InvalidNameException {
		System.out.print("Enter the product ID to update: ");
		String productId = scanner.nextLine();

		Optional<Product> existingProduct = inventoryService.getProductById(productId);
		if (existingProduct.isPresent()) {
			System.out.println("Current Product Details: " + existingProduct.get());

			System.out.print("Enter new name: ");
			String name = scanner.nextLine();
			System.out.print("Enter new description: ");
			String description = scanner.nextLine();
			System.out.print("Enter new price: ");
			double price = scanner.nextDouble();
			System.out.print("Enter new quantity: ");
			int quantity = scanner.nextInt();

			Product updatedProduct = new Product(name, description, price, quantity);
			Product result = inventoryService.updateProduct(productId, updatedProduct);
			System.out.println("Updated Product: " + result);
		} else {
			System.out.println("Product with ID " + productId + " not found.");
		}
	}

	// Delete a product by ID
	public static void deleteProduct(InventoryService inventoryService, Scanner scanner) {
		System.out.print("Enter the product ID to delete: ");
		String productId = scanner.nextLine();

		Optional<Product> product = inventoryService.getProductById(productId);
		if (product.isPresent()) {
			inventoryService.deleteProduct(productId);
			System.out.println("Product with ID " + productId + " deleted successfully.");
		} else {
			System.out.println("Product with ID " + productId + " not found.");
		}
	}
}
