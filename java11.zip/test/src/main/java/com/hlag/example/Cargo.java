package com.hlag.example;


public class Cargo {

	String name;
	String type;
	double weight;

	public Cargo(String name, String type, double weight) {
		this.name = name;
		this.type = type;
		this.weight = weight;
	}

	public String getName() {
		return name;
	}

	public String getType() {
		return type;
	}

	public double getWeight() {
		return weight;
	}

	@Override
	public String toString() {
		return "Cargo [name=" + name + ", type=" + type + ", weight=" + weight + "]";
	}

}
