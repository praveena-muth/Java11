package com.testing.test;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class DeliveryRepositoryImpl implements DeliveryRepository {

	private List<Delivery> deliveries = new ArrayList();

	private static DeliveryRepositoryImpl deliveryRepositoryImpl;

	private DeliveryRepositoryImpl() {

	}

	public static DeliveryRepositoryImpl getInstance() {
		if (deliveryRepositoryImpl == null) {
			deliveryRepositoryImpl = new DeliveryRepositoryImpl();
		}
		return deliveryRepositoryImpl;
	}

	@Override
	public void save(Delivery delivery) {
		deliveries.stream().filter(d -> d.getRevenue() > 50.0).collect(Collectors.toList());

	}

	@Override
	public Optional<Delivery> findById(String deliveryId) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public List<Delivery> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(Delivery delivery) {
		Optional<Delivery> existingDelivery = findById(delivery.getDeliveryId());
		if (existingDelivery.isPresent()) {
			deliveries.remove(existingDelivery.get());
			deliveries.add(delivery);
		}

	}

	public List<Delivery> markDeliveryAsCompleted(Delivery delivery) {
		return deliveries.stream().map(e -> {
			if (e.getDeliveryId().equals(delivery.getDeliveryId())) {
				delivery.setCompleted(true);
				deliveries.add(delivery);
			}
			return delivery;
		}).collect(Collectors.toList());
	}

	public List<Delivery> markDeliveryAsCompleted1(Delivery delivery) {
		return deliveries.stream().filter(e -> e.getDeliveryId().equals(delivery.getDeliveryId())).map(e -> {
			e.setCompleted(true);
			return e;
		}).collect(Collectors.toList());
	}

	@Override
	public void deleteById(String deliveryId) {
		deliveries.removeIf(d -> d.getDeliveryId().equals(deliveryId));

	}

	@Override
	public List<Delivery> findCompletedDeliveries() {
		List<Delivery> completedDeliveries = new ArrayList<>();
		// for (Delivery delivery : deliveries) {
		// if (delivery.isCompleted()) {
		// completedDeliveries.add(delivery);
		// }
		// }
		return completedDeliveries.stream().filter(d -> d.isCompleted()).collect(Collectors.toList());

	}

	// Retrieve deliveries wherevrevenue exceeds a specified threshold(50).

	/*update : Modify Delivery Details
	Mark a Delivery as Completed:
		collection.stream.filter.map.collects(toList)
	collection.stream().map(if condition.collects(toList))*/

	// Delete : Remove Deliveries
	// Remove Completed Deliveries

	// Analysis:Advanced Operations
	// Compute total revenue and average delivery time

	public double calculateTotalRevenue() {
		return deliveries.stream().mapToDouble(e -> e.getRevenue()).sum();
	}

	public double CalculateRevenueTime() {
		return deliveries.stream().mapToDouble(e -> e.getDeliveryTimeInHours()).average().getAsDouble();
	}

	public List<Double> calculateRevenueToTimeRatio() {
		return deliveries.stream().map(e -> e.getRevenue() / e.getDeliveryTimeInHours()).collect(Collectors.toList());
	}

	public List<Delivery> findTopKPerformingDeliveries(int k) {
		return deliveries.stream()
				.filter(e -> e.isCompleted())
				.sorted((a, b) -> Double.compare(a.getDeliveryTimeInHours(), b.getDeliveryTimeInHours()))
				.limit(k)
				.collect(Collectors.toList());
	}

	public double CalculateRevenueTimeThrowException() throws IllegalAccessException {
		return deliveries.stream()
				.mapToDouble(e -> e.getDeliveryTimeInHours())
				.average()
				.orElseThrow(() -> new IllegalAccessException("Data is Not provided"));
	}
}
