package com.testing.test;


public class LambdaexpressionImplement {
public static void main(String[] args) {

	I5 i5 = new I5ipml();
	boolean result = i5.test();
	i5.test2();

}
}

@FunctionalInterface
interface I5 {

	public boolean test();

	public default void test2() {
		System.out.println("hello from test3");
	}
}

class I5ipml implements I5 {

	@Override
	public boolean test() {
		System.out.println("hello from test");
		return true;
	}

	@Override
	public void test2() {
		System.out.println("hello from test2");

	}
}

