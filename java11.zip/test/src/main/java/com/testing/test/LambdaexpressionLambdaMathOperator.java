package com.testing.test;


public class LambdaexpressionLambdaMathOperator {
	
public static void main(String[] args) {
	Maths mathsAdd = (int a, int b) -> a + b;
	int add = mathsAdd.add(10, 20);
	System.out.println(add);

	Maths mathsSub = (int a, int b) -> a - b;
	int sub = mathsSub.add(20, 10);
	System.out.println(sub);

	Maths mathsMulti = (int a, int b) -> a * b;
	int multi = mathsMulti.add(5, 10);
	System.out.println(multi);

	Maths mathsDiv = (int a, int b) -> a / b;
	int div = mathsDiv.add(20, 10);
	System.out.println(div);

}
}
@FunctionalInterface
interface Maths {
public int add(int a,int b);
}
