package com.hlag.userprofilemanagementsystem.repo;

import java.util.ArrayList;
import java.util.List;

import com.hlag.userprofilemanagement.entity.UserProfile;

public class UserProfileRepositoryImpl implements UserProfileRepository {

	private List<UserProfile> userProfileList = new ArrayList();

	private static UserProfileRepositoryImpl userProfileRepositoryImpl;

	public UserProfileRepositoryImpl() {

	}

	public static UserProfileRepositoryImpl getInstance() {
		if (userProfileRepositoryImpl == null) {
			userProfileRepositoryImpl = new UserProfileRepositoryImpl();
		}
		return userProfileRepositoryImpl;
	}

	@Override
	public UserProfile createUser(UserProfile userProfile) {
		return userProfileList.add(userProfile) ? userProfile : null;
	}

	@Override
	public UserProfile findById(String userId) {
		return userProfileList.stream().filter(u -> u.getId().toString().equals(userId)).findFirst().orElse(null);
	}

	@Override
	public List<UserProfile> getAllUserProfile() {
		return userProfileList;
	}

	@Override
	public void updateUserProfile(UserProfile userProfile) {
		userProfileList.stream()
				.filter(u -> u.getId().equals(userProfile.getId()))
				.forEach(u -> {
					u.setName(userProfile.getName());
					u.setAddress(userProfile.getAddress());
					u.setPhoneNumber(userProfile.getPhoneNumber());
				});
	}

	@Override
	public void deleteUserProfile(String userId) {
		userProfileList.removeIf(u -> u.getId().equals(userId));

	}



}
