package com.hlag.userprofilemanagementsystem.repo;

import java.util.List;

import com.hlag.userprofilemanagement.entity.UserProfile;

public interface UserProfileRepository {

	public UserProfile createUser(UserProfile userProfile);

	public UserProfile findById(String userId);

	public List<UserProfile> getAllUserProfile();

	public void updateUserProfile(UserProfile userProfile);

	public void deleteUserProfile(String userId);


}
