package com.hlag.userprofilemanagement.entity;

import java.util.UUID;

public class UserProfile {

	UUID id;
	String name;
	String address;
	Integer phoneNumber;

	public UserProfile() {
	}

	public UserProfile(String name, String address, Integer phoneNumber) {
		this.id = UUID.randomUUID();
		this.name = name;
		this.address = address;
		this.phoneNumber = phoneNumber;
	}

	public UUID getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Integer getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(Integer phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	@Override
	public String toString() {
		return "UserProfile [id=" + id + ", name=" + name + ", address=" + address + ", phoneNumber=" + phoneNumber + "]";
	}

}
